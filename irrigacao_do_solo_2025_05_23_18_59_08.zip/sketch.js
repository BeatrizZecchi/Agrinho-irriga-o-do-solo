// Variáveis para representar o nível de água no solo
let nivelAguaSolo;
let nivelMaximoSolo = 300; // Altura máxima que a água pode atingir no "solo"
let taxaEvaporacao = 0.5; // Quanta água evapora por frame
let taxaIrrigacao = 20;  // Quanta água é adicionada por clique

// Cores
let corSolo = [139, 69, 19]; // Marrom
let corAgua = [0, 191, 255, 150]; // Azul claro transparente
let corPlanta = [34, 139, 34]; // Verde para simular uma planta

function setup() {
  createCanvas(600, 400); // Cria um canvas de 600x400 pixels
  nivelAguaSolo = 50; // Nível inicial de água no solo
}

function draw() {
  background(240); // Fundo claro para o "céu"

  // Desenha a representação do solo
  fill(corSolo[0], corSolo[1], corSolo[2]);
  rect(width / 4, height / 2, width / 2, height / 2); // Retângulo que representa o solo

  // Desenha o nível de água no solo
  fill(corAgua[0], corAgua[1], corAgua[2], corAgua[3]);
  // A altura da água depende do nivelAguaSolo
  let alturaAgua = map(nivelAguaSolo, 0, nivelMaximoSolo, 0, height / 2);
  rect(width / 4, height - alturaAgua, width / 2, alturaAgua);

  // Desenha uma "planta" simples (um triângulo verde) no solo
  fill(corPlanta[0], corPlanta[1], corPlanta[2]);
  let centroSoloX = width / 2;
  let baseSoloY = height;
  let alturaPlanta = map(nivelAguaSolo, 0, nivelMaximoSolo, 20, 100); // Planta cresce com água
  triangle(centroSoloX - 10, baseSoloY - alturaPlanta,
           centroSoloX + 10, baseSoloY - alturaPlanta,
           centroSoloX, baseSoloY);

  // Lógica de Evaporação: O nível de água diminui com o tempo
  nivelAguaSolo -= taxaEvaporacao;

  // Garante que o nível de água não seja negativo (solo não pode ter menos que 0 água)
  nivelAguaSolo = max(0, nivelAguaSolo);
  // Garante que o nível de água não exceda o máximo (solo não transborda)
  nivelAguaSolo = min(nivelMaximoSolo, nivelAguaSolo);

  // Exibe o nível atual de água no solo
  fill(0); // Cor do texto preto
  textSize(16);
  text(`Nível de Água no Solo: ${nf(nivelAguaSolo, 0, 1)}`, 20, 30);
  text('Clique para Irrigar!', 20, 50);

  // Dica: A "planta" cresce e diminui conforme o nível de água!
}

function mousePressed() {
  // Quando o mouse é clicado, adiciona água ao solo
  nivelAguaSolo += taxaIrrigacao;
}